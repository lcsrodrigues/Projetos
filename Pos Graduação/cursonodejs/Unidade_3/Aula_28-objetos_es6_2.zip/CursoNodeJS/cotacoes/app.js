const cotacao = require('./util/cotacao')

cotacao('VALE5', (data) =>{
    console.log(data)
})