const _ = require('lodash')
const chalk = require('chalk')

const command = process.argv[2].toUpperCase();
const name = process.argv[3]

if (command === 'ADD'){
    console.log(chalk.green.inverse(`adding new task -> ${name}`))
} else if (command === 'REMOVE'){
    console.log(chalk.blue.inverse('removing a task'))
} else {
    console.log(chalk.red.inverse('command not found'))
}

console.log('hello')


