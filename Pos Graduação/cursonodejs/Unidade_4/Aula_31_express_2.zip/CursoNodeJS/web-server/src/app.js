const express = require('express')

const app = express()

// minhaapp.com.br
// minhaapp.com.br/help
// minhaapp.com.br/about

app.get('', (req, res) =>{
    res.send('<h1>Hello minha app</h1>')
})

app.get('/help', (req, res) => {
    res.send('help page')
})

// definir a rota do about

app.get('/about', (req, res) => {
    res.send('I am at the about page')
})

// definir uma rota para o /cotacoes
app.get('/cotacoes', (req, res) => {
    const cotacao = {
        symbol : 'PETR4.SA', 
        price_open: 10, 
        price : 12, 
        day_high : 13, 
        day_low : 9    
    }

    const cotacoes = new Array()
    cotacoes.push(cotacao)
    cotacoes.push(cotacao)

    res.send(cotacoes)
})

app.listen(3000, () => {
    console.log('server is up on port 3000')
})