# Projeto cotações

# para executar configure as dependências
`npm i`

# depois
`npm start`