import * as React from 'react';
import { Text, View, StyleSheet } from 'react-native';
import Constants from 'expo-constants';

// or any pure javascript modules available in npm
import { Button } from 'react-native-paper';

export default function App() {

  digaOla = () =>{
    alert("Olá Lucas")
  }

  return (
    <View style={styles.app}>
      <Text style={styles.text}>Seu IMC</Text>

    </View>
  );
}

const styles = StyleSheet.create({
  app: {
    
  },
});
