import React,{useState, useEffect} from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  AsyncStorage
} from "react-native";

import Icon from 'react-native-vector-icons/MaterialIcons'

const Book = ({navigation}) => {

  const book = navigation.getParam("book",{
    title:'',
    description:'',
    read:false,
    photo:''
  })

  const isEdit = navigation.getParam("isEdit")

  const[books, setBooks] = useState([])
  const[title,setTitle] = useState(book.title)
  const[description,setDescription] = useState(book.description)
  const[read, setRead] = useState(book.read)
  const[photo,setPhoto] = useState(book.photo)

  useEffect(() =>{
    
    AsyncStorage.getItem("books").then(data =>{
      const book = JSON.parse(data) || []
      setBooks(book)
    })

  },[])

  const isValid = () => {
    if(title != undefined && title != "" && title.length > 2){
      return true
    }

    return false;
  }

  const onSave = async () => {
    
    if(isValid())
    {
      if(isEdit)
      {
        let newBooks = books;
        newBooks.map(item =>{
          if(item.id === book.id){
            item.title = title;
            item.description = description;
            item.read = read;
            item.photo = photo;
          }
          return item;
        })

        await AsyncStorage.setItem("books",JSON.stringify(newBooks));
        navigation.navigate("Main")

      }else{
        const id = Math.random(5000).toString()
        const data = {
          id,
          title,
          description,
          photo
        }
        await books.push(data)
        await AsyncStorage.setItem("books",JSON.stringify(books));
        navigation.navigate("Main")
      }
    }else{
      alert("Preencha os campos obrigatórios")
    }
  }

  return(
    <View style={styles.container}>
      <Text style={styles.pageTitle}>Inclua seu novo livro...</Text>
        <TextInput style={styles.input}
          placeholder="Título"
          value={title}
          onChangeText={(text)=>{
              setTitle(text)
          }}
        />
        <TextInput style={styles.input}
          placeholder="Descrição"
          multiline={true}
          numberOfLines={4}
          value={description}
          onChangeText={(description)=>{
            setDescription(description)
          }}
        />
        <TouchableOpacity style={styles.cameraButton}>
          <Icon name="photo-camera" size={30} color="#fff" />
        </TouchableOpacity>
        
        <TouchableOpacity style={styles.saveButton}
        onPress={onSave}
        >
          <Text style={styles.saveButtonText}>Salvar</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.cancelButton}
        onPress={() => {
            navigation.goBack()
        }}>
          <Text style={styles.cancelButtonText}>Cancelar</Text>
        </TouchableOpacity>
    </View>
  )
}

const styles = StyleSheet.create({
  container:{
    flex:1,
    padding:10
  },
  pageTitle:{
    textAlign:"center",
    fontSize:16,
    marginBottom:20
  },
  input:{
    fontSize:16,
    borderBottomColor:"#f39c12",
    borderBottomWidth:1,
    marginBottom:25
  },
  cameraButton:{
    backgroundColor:"#3498db",
    borderRadius:50,
    width:60,
    height:60,
    justifyContent:"center",
    alignItems:"center",
    alignSelf:"center",
    marginBottom:25
  },
  // saveButtonInvalid:{
  //   opacity:0.5
  // },
  saveButton:{
    backgroundColor:"#f39c12",
    alignSelf:"center",
    borderRadius:8,
    paddingVertical:10,
    paddingHorizontal:20,
    marginBottom:20
  },
  saveButtonText:{
    color:"#fff",
    fontSize:16
  },
  cancelButton:{
    backgroundColor:"#ff0000",
    alignSelf:"center",
    borderRadius:8,
    paddingVertical:10,
    paddingHorizontal:20
  },
  cancelButtonText:{
    color:"#fff",
    fontSize:16
  }
})

export default Book;